To use, please put first the configuration JS.
For example:
<script src="turnkey88.conf.js"></script>
<script src="integration.js"></script>