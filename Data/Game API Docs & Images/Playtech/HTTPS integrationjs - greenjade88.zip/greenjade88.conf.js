iapiConf = {
"loginServer":"login.grandmandarin88.com",
"loginDomainRetryCount":"2",
"loginDomainRequestTimeout":"30",
"loginDomainRetryInterval":"1",

"casinoname":"greenjade88",
"clientSkin":"greenjade88",
"clientType":"casino",
"clientPlatform":"flash",
"clientVersion":"42",

"systemId":"697",
"serviceType":"GamePlay",

"redirectUrl":"/integration/integrationRedirect.html",
"useMessages":"1",

"clientUrl_casino":"http://cache.download.banner.greenjade88.com/casinoclient.html",

"windowSizes":{"0":"width=800,height=624", "1":"width=1024,height=768"},
"windowSize_casino":{"default":"0", "bjl":"1"}

}