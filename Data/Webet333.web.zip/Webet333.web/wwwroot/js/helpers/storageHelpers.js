﻿function SetLocalStorage(name, value) {
    localStorage.setItem(name, value);
}

function GetLocalStorage(name) {
    return localStorage.getItem(name);
}