﻿var M8baseUrl = "http://apir.mywinday.com/api.aspx?";

var M8ConstParameter = {
    secret: "secret=a782988d",
    agent: "agent=0a1a"
};

var M8ConstAction = {
    createAction: "action=create",
    loginAction: "action=login",
    balanceAction: "action=balance",
    depositAction: "action=deposit",
    logoutAction: "action=logout",
    withdrawalAction: "action=withdraw"
};