﻿var walletName = {
    m8wallet: 'M8 Wallet'
}

var GameNames = {
    AG: 'AG',
    Playtech: 'Playtech',
    M8: 'M8',
    MaxBet: 'MaxBet',
    DG: 'DG',
    SexyBaccarat: 'Sexy Baccarat',
    SA: 'SA',
    AllBet: 'AllBet',
    WM: 'WM',
    YeeBet: 'YeeBet',
    Joker: 'Joker',
    Mega888: 'Mega888',
    _918Kiss: '918 Kiss',
    Pussy888: 'Pussy888',
    PragmaticPlay: 'Pragmatic Play',
    SBO: 'SBO'
}

var WalletNames = {
    MainWallet: 'Main Wallet',
    AGWallet: 'AG Wallet',
    PlaytechWallet: 'PlayTech Wallet',
    M8Wallet: 'M8 Wallet',
    MaxBetWallet: 'MaxBet Wallet',
    DGWallet: 'DG Wallet',
    SexyWallet: 'Sexy Wallet',
    SAWallet: 'SA Wallet',
    AllBetWallet: 'AllBet Wallet',
    WMWallet: 'WM Wallet',
    YeeBetWallet: 'YeeBet Wallet',
    JokerWallet: 'Joker Wallet',
    Mega888Wallet: 'Mega888 Wallet',
    _918KissWallet: '918Kiss Wallet',
    Pussy888Wallet: 'Pussy888 Wallet',
    PragmaticPlayWallet: 'Pragmatic Wallet',
    SBOWallet: 'SBO Wallet',
}